<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>New Test Suite</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>ae149c69-cf44-4f53-91bb-cc91b9fa0871</testSuiteGuid>
   <testCaseLink>
      <guid>f6104297-5d4a-46b3-b0d6-1a1cd7bb2b5e</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Click on Image Test</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>989b388f-405b-48d7-be1a-eef6171f3d8b</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Click on Image in Image test</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
